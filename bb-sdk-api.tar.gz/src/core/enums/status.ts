enum Status {
  Active = 0,
  Inactive = 1,
}

export { Status };
