export enum MeetingStatus {
  Active = 0,
  Archived = 1,
}
