export enum RecordStatus {
  Recording = 0,
  Processing = 1,
  Finish = 2,
}
