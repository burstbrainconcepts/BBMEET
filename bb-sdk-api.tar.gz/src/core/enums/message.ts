export enum MessageType {
  Default,
  System,
}
