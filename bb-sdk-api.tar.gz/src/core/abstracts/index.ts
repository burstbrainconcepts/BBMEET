export * from './generic-repository.abstract';
