export class LeaveMeetingDto {
  // @ApiProperty()
  // @IsNumber()
  // participantId: number;
}
